﻿using HIOF.V2025.BookApp.BookStore;

namespace HIOF.V2025.BookApp.BookCLI;

internal class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("Hello, World!");
    }
}
